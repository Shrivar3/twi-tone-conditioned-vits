from pathlib import Path

expected = [
    "README.md",
    "requirements.txt",
    ".gitignore",
    ".env.example",
    "configs/week1_eval.yaml",
    "configs/text_normalisation.yaml",
    "notebooks/01_dataset_audit.ipynb",
    "scripts/01_make_dev_set.py",
    "scripts/02_run_baseline_tts.py",
    "scripts/03_run_asr_wer.py",
    "scripts/04_annotate_tone.py",
    "src/data/load_hf_dataset.py",
    "src/data/make_dev_set.py",
    "src/data/text_normalise.py",
    "src/eval/synth_baseline.py",
    "src/eval/asr_transcribe.py",
    "src/eval/compute_wer.py",
    "src/eval/mos_form_export.py",
    "src/tone/annotate_tone.py",
    "src/tone/validate_tone_annotations.py",
    "src/utils/paths.py",
    "data/README.md",
    "results/week1_summary.md",
]

bad_root = [
    "01_dataset_audit.ipynb",
    "01_make_dev_set.py",
    "03_run_asr_wer.py",
    "04_annotate_tone.py",
    "annotate_tone.py",
    "asr_transcribe.py",
    "compute_wer.py",
    "make_dev_set.py",
    "mos_form_export.py",
    "paths.py",
    "validate_tone_annotations.py",
    "week1_eval.yaml",
    "week1_summary.md",
]

missing = [p for p in expected if not Path(p).exists()]
still_bad = [p for p in bad_root if Path(p).exists()]

print("Structure check")
print("---------------")
if missing:
    print("Missing expected files:")
    for p in missing:
        print(f"  - {p}")
else:
    print("Missing expected files: None")

if still_bad:
    print("\nBad root-level files still present:")
    for p in still_bad:
        print(f"  - {p}")
else:
    print("Bad root-level files still present: None")

raise SystemExit(1 if missing or still_bad else 0)
