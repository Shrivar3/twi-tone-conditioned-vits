#!/usr/bin/env bash
set -euo pipefail

STARTER_ZIP="${1:-}"
if [[ -z "$STARTER_ZIP" ]]; then
  echo "Usage: bash repair_repo_from_starter.sh /path/to/twi-tone-conditioned-vits-starter.zip"
  exit 1
fi
if [[ ! -f "$STARTER_ZIP" ]]; then
  echo "Could not find starter zip: $STARTER_ZIP"
  exit 1
fi
if [[ ! -d .git ]]; then
  echo "Run this from the root of your cloned GitHub repo, where the .git folder exists."
  exit 1
fi

BACKUP_BRANCH="backup-before-week1-cleanup-$(date +%Y%m%d-%H%M%S)"
git branch "$BACKUP_BRANCH"
echo "Created local backup branch: $BACKUP_BRANCH"

# Remove files that were accidentally uploaded flat into the root.
git rm -f --ignore-unmatch \
  01_dataset_audit.ipynb \
  01_make_dev_set.py \
  03_run_asr_wer.py \
  04_annotate_tone.py \
  README.md \
  requirements.txt \
  week1_eval.yaml \
  week1_summary.md \
  annotate_tone.py \
  asr_transcribe.py \
  compute_wer.py \
  make_dev_set.py \
  mos_form_export.py \
  paths.py \
  validate_tone_annotations.py \
  "__init__.py" \
  "__init__ (1).py" \
  "__init__ (4).py" \
  "download (8)" || true

rm -f \
  01_dataset_audit.ipynb \
  01_make_dev_set.py \
  03_run_asr_wer.py \
  04_annotate_tone.py \
  README.md \
  requirements.txt \
  week1_eval.yaml \
  week1_summary.md \
  annotate_tone.py \
  asr_transcribe.py \
  compute_wer.py \
  make_dev_set.py \
  mos_form_export.py \
  paths.py \
  validate_tone_annotations.py \
  "__init__.py" \
  "__init__ (1).py" \
  "__init__ (4).py" \
  "download (8)" || true

TMPDIR="$(mktemp -d)"
unzip -q "$STARTER_ZIP" -d "$TMPDIR"
if [[ ! -d "$TMPDIR/twi-tone-conditioned-vits-starter" ]]; then
  echo "Starter zip did not contain expected folder: twi-tone-conditioned-vits-starter"
  exit 1
fi

# Copy correct structure into repo root.
cp -R "$TMPDIR/twi-tone-conditioned-vits-starter/"* ./
cp -R "$TMPDIR/twi-tone-conditioned-vits-starter/".[!.]* ./ 2>/dev/null || true
rm -rf "$TMPDIR"

python - <<'PY'
from pathlib import Path
expected = [
    "README.md",
    "requirements.txt",
    ".gitignore",
    ".env.example",
    "configs/week1_eval.yaml",
    "configs/text_normalisation.yaml",
    "notebooks/01_dataset_audit.ipynb",
    "scripts/01_make_dev_set.py",
    "scripts/02_run_baseline_tts.py",
    "scripts/03_run_asr_wer.py",
    "scripts/04_annotate_tone.py",
    "src/data/load_hf_dataset.py",
    "src/data/make_dev_set.py",
    "src/data/text_normalise.py",
    "src/eval/synth_baseline.py",
    "src/eval/asr_transcribe.py",
    "src/eval/compute_wer.py",
    "src/eval/mos_form_export.py",
    "src/tone/annotate_tone.py",
    "src/tone/validate_tone_annotations.py",
    "src/utils/paths.py",
    "data/README.md",
    "results/week1_summary.md",
]
bad_root = [
    "01_dataset_audit.ipynb",
    "01_make_dev_set.py",
    "03_run_asr_wer.py",
    "04_annotate_tone.py",
    "annotate_tone.py",
    "asr_transcribe.py",
    "compute_wer.py",
    "make_dev_set.py",
    "mos_form_export.py",
    "paths.py",
    "validate_tone_annotations.py",
    "week1_eval.yaml",
    "week1_summary.md",
]
missing = [p for p in expected if not Path(p).exists()]
still_bad = [p for p in bad_root if Path(p).exists()]
print("\nStructure check")
print("---------------")
print("Missing expected files:", missing or "None")
print("Bad root-level files still present:", still_bad or "None")
if missing or still_bad:
    raise SystemExit(1)
PY

echo "\nRepo structure repaired locally. Review with: git status --short"
echo "Then commit and push with:"
echo "  git add ."
echo "  git commit -m 'Fix Week 1 starter repo structure'"
echo "  git push origin main"
echo "\nLocal backup branch created: $BACKUP_BRANCH"
